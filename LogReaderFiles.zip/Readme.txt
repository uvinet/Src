LogReader - основные файлы cpp/h файлы класса СLogReader + вспомогательные файлы

TestProject - консольный пример использования СLogReader (VS2005), запуск с аргументами: имя_файла "<выборка>"

TestProject\test_orders.log - тестовый файл, 2Мб.

Test.bat - батник, запускающий тест для файла test_orders.log с выборкой "order*closed"